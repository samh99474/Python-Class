def main(student_list):
    print ("\n==== student list ====\n")





    
    print ("======================")
