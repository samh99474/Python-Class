1. 開啟server資料夾:
在cmd打:python main_server.py
即可開啟local伺服器

2.打開client資料夾:
在VScode裡的terminal終端機打:python ./main_client.py

3. 如何結束?
在client terminal輸入"close"，傳送給server端(即可終止連線)
最後在server端cmd打"finish"


4.如何開啟example.db(SQLite)
在 Server資料夾 >> DB Browser for SQLite資料夾 >> 打開"DB Browser for SQLite.exe" >> 從browser軟體打開舊檔案"example.db"